package com.company;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class test{

    public void parseXml() throws IOException, SAXException, ParserConfigurationException {

        try {

            Path filePath= Paths.get("/Users/shadi/IdeaProjects/ktlin/xmli/src/com/company/prod.xml");
            File inputFile = new File(String.valueOf(filePath));
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("bar");


            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;


                    System.out.println("product serial number : " +
                            eElement.getAttribute("SN"));

                    System.out.println("prot: " +
                            eElement.getElementsByTagName("protein").item(0).getTextContent());


                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }


    }

}
